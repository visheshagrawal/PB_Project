<!DOCTYPE HTML>

<html>
	<head>
		<title>Quarantine Buddy</title>
		<meta charset="utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
		<link rel="stylesheet" href="assets/css/main.css" />
		<link rel="stylesheet" href="popup/css.css"/>
		<link href="https://fonts.googleapis.com/css?family=Roboto:300,400" rel="stylesheet">
		<noscript><link rel="stylesheet" href="assets/css/noscript.css" /></noscript>
	</head>
	<body class="homepage is-preload">
		<div id="page-wrapper">

			<!-- Header -->
				<div id="header">

					<!-- Inner -->
						<div class="inner">
							<header>
								<h1><a id="logo">Quarantine Buddy</a></h1>
								<hr />
								<p>An Initiative by the students of IIITD</p>
							</header>
							<footer>
								<a href="#banner" class="button circled scrolly">Start</a>
							</footer>
						</div>

					<!-- Nav -->
						<nav id="nav">
							<ul>
								<li><a >Covid Updates</a></li>
								<li><a href="main.php">Home</a></li>
								<li>
									<a href="#moods">How are you feeling today?</a>
								</li>
								<li>
									<a href="#fun">FUN</a>
								</li>
								<li>
									<a href="#shareyourstory">Share your story</a>
								</li>
								
							</ul>
						</nav>

				</div>

			<!-- Banner -->
				<section id="banner">
					<header>
						<h2>Hey there! What do you feel right now ? </h2>
						<p>
						</p>
					</header>
				</section>

			<!-- Carousel -->
				<section class="carousel" id="moods">
					<div class="reel">

						<article>
							<a class="image featured"><img src="images/pic01.jpg" alt="" /></a>
							<header>
								<h3><a >A little too good to be true</a></h3>
							</header>
							<p>Glad to hear</p>
							<button class="button" data-modal="#happy_symptoms">
								<a >Symptoms</a>
							</button>
							<br><br>
							<button class="button" data-modal="#happy_whattodonext">
								<a>What to do next</a>
							</button>


						</article>

						<article>
							<a  class="image featured"><img src="images/okay.gif" alt="" /></a>
							<header>
								<h3><a >Not in the mood to party but not bad either</a></h3>
							</header>
							<p>You're doing fine, don't sweat it</p>
							<button class="button" data-modal="#okayish_symptoms">
								<a>Symptoms</a>
							</button>
							<br><br>
							<button class="button" data-modal="#okayish_whattodonext" >
								<a>What to do next</a>
							</button>
						</article>

						<article>
							<a  class="image featured"><img src="images/anxious.gif" alt="" /></a>
							<header>
								<h3><a >Anxiety making your head explode?</a></h3>
							</header>
							<p>Yikes!</p>
							<button class="button" data-modal="#anxious_symptoms">
								<a>Symptoms</a>
							</button>
							<br><br>
							<button class="button" data-modal="#anxious_whattodonext">
								<a>What to do next</a>
							</button>
						</article>

						<article>
							<a  class="image featured"><img src="images/cleithrophobia.gif" alt="" /></a>
							<header>
								<h3><a >Feeling trapped inside?</a></h3>
							</header>
							<p>Oh no!</p>
							<button class="button" data-modal="#cleithrophobia_symptoms">
								<a>Symptoms</a>
							</button>
							<br><br>
							<button class="button" data-modal="#cleithrophobia_whattodonext">
								<a>What to do next</a>
							</button>
						</article>

						<article>
							<a  class="image featured"><img src="images/paranoia.jpg" alt="" /></a>
							<header>
								<h3><a >Paranoia won't let you be?</a></h3>
							</header>
							<p>Oof!</p>
							<button class="button" data-modal="#paranoia_symptoms">
								<a>Symptoms</a>
							</button>
							<br><br>
							<button class="button" data-modal="#paranoia_whattodonext">
								<a>What to do next</a>
							</button>
						</article>

						<article>
							<a  class="image featured"><img src="images/frustrated.gif" alt="" /></a>
							<header>
								<h3><a >Frustration Getting the best of you?</a></h3>
							</header>
							<p>Ugh!</p>
							<button class="button" data-modal="#frustration_symptoms">
								<a>Symptoms</a>
							</button>
							<br><br>
							<button class="button" data-modal="#frustration_whattodonext">
								<a>What to do next</a>
							</button>
						</article>

						<article>
							<a  class="image featured"><img src="images/sad.gif" alt="" /></a>
							<header>
								<h3><a >Feeling like a sad little pupper?</a></h3>
							</header>
							<p>Uh-oh!</p>
							<button class="button" data-modal="#sad_symptoms">
								<a>Symptoms</a>
							</button>
							<br><br>
							<button class="button" data-modal="#sad_whattodonext">
								<a>What to do next</a>
							</button>
							
						</article>

						<article>
							<a  class="image featured"><img src="images/FEAR.jpg" alt="" /></a>
							<header>
								<h3><a >Fear of the future breaking you down?</a></h3>
							</header>
							<p></p>
							<button class="button" data-modal="#fear_symptoms">
								<a>Symptoms</a>
							</button>
							<br><br>
							<button class="button" data-modal="#fear_whattodonext">
								<a>What to do next</a>
							</button>
						</article>

						<article>
							<a  class="image featured"><img src="images/insomnia.gif" alt="" /></a>
							<header>
								<h3><a >Can't get enough sleep?</a></h3>
							</header>
							<p>Yeesh!</p>
							<button class="button" data-modal="#insomnia_symptoms" >
								<a>Symptoms</a>
							</button>
							<br><br>
							<button class="button" data-modal="#insomnia_whattodonext">
								<a>What to do next</a>
							</button>
						</article>

						<article>
							<a  class="image featured"><img src="images/lonely.gif" alt="" /></a>
							<header>
								<h3><a >Loneliness sap all the colours from your life?</a></h3>
							</header>
							<p>Darn it!</p>
							<button class="button" data-modal="#lonely_symptoms">
								<a>Symptoms</a>
							</button>
							<br><br>
							<button class="button" data-modal="#lonely_whattodonext">
								<a>What to do next</a>
							</button>
						</article>

						<article>
							<a  class="image featured"><img src="images/homesick.gif" alt="" /></a>
							<header>
								<h3><a >Feeling too far from home?</a></h3>
							</header>
							<p>:(</p>
							<button class="button" data-modal="#homesick_symptoms">
								<a>Symptoms</a>
							</button>
							<br><br>
							<button class="button" data-modal="#homesick_whattodonext">
								<a>What to do next</a>
							</button>
						</article>


						<!-- DEFINING ALL THE MODAL POPUPS HERE-->
						<!-- <div class="modal" id="happy_symptoms">
							<center>
								<h1><b>Symptoms: </b></h1>
									<ul>
										<li>A smile on your face</li>
										<li>Spring in you step</li>
										<li>Sparkly eyes</li>
										<li>Content and satisfied</li>
										<li>Glass half full mentality</li>
										<li>Taking each day in a stride</li>
									</ul>
							</center> -->
						<!-- </div> -->
						<div class="modal" id="happy_symptoms">
							<center><h2>
								<br><br>
								<button style="font-size: x-large;">
									<p style="font-size: x-large;">
									<ul>
										<li>A smile on your face</li>
										<li>Spring in you step</li>
										<li>Sparkly eyes</li>
										<li>Content and satisfied</li>
										<li>Glass half full mentality</li>
										<li>Taking each day in a stride</li>
									  </ul>
									  </p>
								</button>
								</h2>
							</center>
						</div>
						<div class="modal" id="happy_whattodonext">
							<center><h3>
								<br><br>
									<p style="font-size:large;">
								<ul class="actions">
									<li><a target="_blank" href="https://www.reddit.com/r/UpliftingNews/" class="button">Uplifting News</a></li>
								  </ul>
			
								  <ul class="actions">
									<li><a href="#help" class="button">share your story</a></li>
								  </ul>
								</p>
							</h3>
							</center>
						</div>
						<div class="modal" id="okayish_symptoms">
							<center><h2>
								<br><br>
								<button style="font-size: x-large;">
									<p style="font-size: x-large;">
									<ul>
										<li>Satisfied to a certain extent</li>
                        				<li>Can't complain about how thing are going</li>
                       					<li>Might not be having the best time, but it's not bad</li>
									  </ul>
									  </p>
								</button>
								</h2>
							</center>
						</div>
						<div class="modal" id="okayish_whattodonext">
							<center><h3>
								<br><br>
									<p style="font-size:large;">
										<ul class="actions">
											<li><a target="_blank" href="https://www.reddit.com/r/UpliftingNews/" class="button">Uplifting News</a></li>
										  </ul>
										  
										  <ul class="actions">
											<li><a href="#help" class="button">share your story</a></li>
										  </ul>
								</p>
							</h3>
							</center>
						</div>
						<div class="modal" id="anxious_symptoms">
							<center><h2>
								<br><br>
								<button style="font-size: x-large;">
									<p style="font-size: x-large;">
									<ul>
										<li>Stressed out</li>
										<li>Panic, fear, and uneasiness</li>
										<li>Not being able to stay calm and still</li>
										<li>Cold, sweaty, numb or tingling hands or feet</li>
										<li>Shortness of breath</li>
										<li>Heart palpitations</li>
										<li>Dry Mouth</li>
										<li>Nausea</li>
										<li>Tense Muscles</li>
										<li>Dizziness</li>
										<li>Excessive worrying</li>
									  </ul>
									  </p>
								</button>
								</h2>
							</center>
						</div>
						<div class="modal" id="anxious_whattodonext">
							<center><h4>
								<br><br>
									<p style="font-size:large;">
										<ul class="actions">
											<li><a target="_blank" href="https://www.bbc.com/news/health-52443108" class="button">This article might help</a></li>
										  </ul>
					
										  <ul class="actions">
											<li><a target="_blank" href="https://www.webmd.com/anxiety-panic/ss/slideshow-ways-to-stop-panic-attack" class="button">Ways to Stop a Panic Attack</a></li>
										  </ul>
					
										  <ul class="actions">
											<li><a target="_blank" href="https://hasofferstracking.betterhelp.com/aff_c?offer_id=25&aff_id=1510&aff_sub3=n99d6ddb9e5e04d1e87e06d3f59f4238521" class="button">Counselling for teens</a></li>
										  </ul>
					
										  <ul class="actions">
											<li><a target="_blank" href="http://understandinganxiety.wayahead.org.au/online-anxiety-and-mental-health-resources/" class="button">Online Anxiety and Mental Health Resources</a></li>
										  </ul>
					
										  <ul class="actions">
											<li><a href="#help" class="button">share your story</a></li>
										  </ul>
					
								</p>
							</h4>
							</center>
						</div>
						<div class="modal" id="cleithrophobia_symptoms">
							<center><h2>
								<br><br>
								<button style="font-size: x-large;">
									<p style="font-size: x-large;">
									<ul>
										<li>Dread</li>
										<li>Speedy respiration</li>
										<li>Irregular heartbeat</li>
										<li>Inability to articulate words/sentences</li>
										<li>Shaking</li>
										<li>Need to escape</li>
										<li>Lashing out</li>
										<li>Freezing up</li>
									  </ul>
									  </p>
								</button>
								</h2>
							</center>
						</div>
						<div class="modal" id="cleithrophobia_whattodonext">
							<center><h3>
								<br><br>
									<p style="font-size:large;">
										<ul class="actions">
											<li><a target="_blank" href="https://hasofferstracking.betterhelp.com/aff_c?offer_id=25&aff_id=1510&aff_sub3=n99d6ddb9e5e04d1e87e06d3f59f4238521" class="button">Counselling for teens</a></li>
										  </ul>
					
										  <ul class="actions">
											<li><a target="_blank" href="https://driveandlisten.herokuapp.com" class="button">Travel the world!</a></li>
										  </ul>
					
										  <ul class="actions">
											<li><a href="#help" class="button">share your story</a></li>
										  </ul>
									</p>
							</h3>
							</center>
						</div>

						<div class="modal" id="paranoia_symptoms">
							<center><h2>
								<br><br>
								<button style="font-size: x-large;">
									<p style="font-size: x-large;">
									<ul>
										<li>Being defensive, hostile, and aggressive</li>
										<li>Being easily offended</li>
										<li>Believing you are always right and having trouble relaxing or letting your guard down</li>
										<li>Not being able to compromise, forgive, or accept criticism</li>
										<li>Not being able to trust or confide in other people</li>
										<li>Reading hidden meanings into people’s normal behaviors</li>
									  </ul>
									  </p>
								</button>
								</h2>
							</center>
						</div>
						<div class="modal" id="paranoia_whattodonext">
							<center><h4>
								<br><br>
									<p style="font-size:large;">
										<ul class="actions">
											<li><a target="_blank" href="https://hasofferstracking.betterhelp.com/aff_c?offer_id=25&aff_id=1510&aff_sub3=n99d6ddb9e5e04d1e87e06d3f59f4238521" class="button">Counselling for teens</a></li>
										  </ul>
					
										  <ul class="actions">
											<li><a target="_blank" href="https://www.reddit.com/r/UpliftingNews/" class="button">Uplifting News</a></li>
										  </ul>
					
										  <ul class="actions">
											<li><a target="_blank" href="https://www.webmd.com/anxiety-panic/ss/slideshow-ways-to-stop-panic-attack" class="button">Ways to Stop a Panic Attack</a></li>
										  </ul>
					
										  <ul class="actions">
											<li><a target="_blank" href="https://www.webmd.com/mental-health/why-paranoid#4-6" class="button">Treatment</a></li>
										  </ul>
					
										  <ul class="actions">
											<li><a href="#help" class="button">share your story</a></li>
										  </ul>
					
								</p>
							</h4>
							</center>
						</div>
						<div class="modal" id="frustration_symptoms">
							<center><h2>
								<br><br>
								<button style="font-size: x-large;">
									<p style="font-size: x-large;">
									<ul>
										<li>Easily Annoyed</li>
										<li>Want to engage in negative/destructive behaviours</li>
									  </ul>
									  </p>
								</button>
								</h2>
							</center>
						</div>
						<div class="modal" id="frustration_whattodonext">
							<center><h4>
								<br><br>
									<p style="font-size:large;">
										<ul class="actions">
												<li><a target="_blank" href="https://www.reddit.com/r/UpliftingNews/" class="button">Uplifting News</a></li>
										  </ul>
					
										<ul class="actions">
											<li><a target="_blank" href="chat.php" class="button">Try our online chat forum</a></li>
										</ul>
				
				
										<ul class="actions">
											<li><a target="_blank" href="https://www.puzzler.com/online-puzzles/" class="button">Puzzles</a></li>
										</ul>
				
										<ul class="actions">
											<li><a href="#help" class="button">share your story</a></li>
										</ul>
								</p>
							</h4>
							</center>
						</div>

						<div class="modal" id="sad_symptoms">
							<center><h2>
								<br><br>
								<button style="font-size: x-large;">
									<p style="font-size: x-large;">
									<ul>
										<li>Trouble concentrating, remembering details, and making decisions</li>
										<li>Fatigue</li>
										<li>Feelings of guilt, worthlessness, and helplessness</li>
										<li>Pessimism and hopelessness</li>
										<li>Insomnia, early-morning wakefulness, or sleeping too much</li>
										<li>Irritability</li>
										<li>Restlessness</li>
										<li>Loss of interest in things once pleasurable, including sex</li>
										<li>Overeating, or appetite loss</li>
										<li>Aches, pains, headaches, or cramps that won't go away</li>
										<li>Digestive problems that don't get better, even with treatment</li>
										<li>Persistent sad, anxious, or "empty" feelings</li>
										<li>Suicidal thoughts or attempts</li>
										<li>Changes in your menstrual cycle</li>
									  </p>
								</button>
								</h2>
							</center>
						</div>
						<div class="modal" id="sad_whattodonext">
							<center><h4>
								<br><br>
									<p style="font-size:large;">
										<ul class="actions">
											<li><a target="_blank" href="https://www.reddit.com/r/UpliftingNews/" class="button">Uplifting News</a></li>
										  </ul>
					
										  <ul class="actions">
											<li><a target="_blank" href="chat.php" class="button">Try our online chat forum</a></li>
										  </ul>
					
										  <ul class="actions">
											<li><a target="_blank" href="https://hasofferstracking.betterhelp.com/aff_c?offer_id=25&aff_id=1510&aff_sub3=n99d6ddb9e5e04d1e87e06d3f59f4238521" class="button">Counselling for teens</a></li>
										  </ul>
					
										  <ul class="actions">
											<li><a target="_blank" href="https://www.puzzler.com/online-puzzles/" class="button">Puzzles</a></li>
										  </ul>
					
										  <ul class="actions">
											<li><a href="#help" class="button">share your story</a></li>
										  </ul>
								</p>
							</h4>
							</center>
						</div>

						<div class="modal" id="fear_symptoms">
							<center><h2>
								<br><br>
								<button style="font-size: x-large;">
									<p style="font-size: x-large;">
									<ul>
										<li>A smile on your face</li>
										<li>Spring in you step</li>
										<li>Sparkly eyes</li>
										<li>Content and satisfied</li>
										<li>Glass half full mentality</li>
										<li>Taking each day in a stride</li>
									  </ul>
									  </p>
								</button>
								</h2>
							</center>
						</div>
						<div class="modal" id="fear_whattodonext">
							<center><h3>
								<br><br>
									<p style="font-size:large;">
								<ul class="actions">
									<li><a target="_blank" href="https://www.reddit.com/r/UpliftingNews/" class="button">Uplifting News</a></li>
								  </ul>
			
								  <ul class="actions">
									<li><a href="#help" class="button">share your story</a></li>
								  </ul>
								</p>
							</h3>
							</center>
						</div>
						<div class="modal" id="insomnia_symptoms">
							<center><h2>
								<br><br>
								<button style="font-size: x-large;">
									<p style="font-size: x-large;">
									<ul>
										<li>Difficulty falling asleep</li>
										<li>Not feeling well rested after waking up</li>
										<li>Waking up too early</li>
										<li>Daytime sleepiness</li>
										<li>Problems with memory and concentration</li>
										<li>Ongoing worries about sleep</li>
										</ul>
									</p>
								</button>
								</h2>
							</center>
						</div>
						<div class="modal" id="insomnia_whattodonext">
							<center><h3>
								<br><br>
									<p style="font-size:large;">
										<ul class="actions">
											<li><a target="_blank" href="https://www.webmd.com/sleep-disorders/understanding-insomnia-treatment" class="button">Treatment</a></li>
										  </ul>
					
										  <ul class="actions">
											<li><a target="_blank" href="https://hasofferstracking.betterhelp.com/aff_c?offer_id=25&aff_id=1510&aff_sub3=n99d6ddb9e5e04d1e87e06d3f59f4238521" class="button">Counselling for teens</a></li>
										  </ul>
					
										  <ul class="actions">
											<li><a href="#help" class="button">share your story</a></li>
										  </ul>
								</p>
							</h3>
							</center>
						</div>
						<div class="modal" id="lonely_symptoms">
							<center><h2>
								<br><br>
								<button style="font-size: x-large;">
									<p style="font-size: x-large;">
									<ul>
										<li>A smile on your face</li>
										<li>Spring in you step</li>
										<li>Sparkly eyes</li>
										<li>Content and satisfied</li>
										<li>Glass half full mentality</li>
										<li>Taking each day in a stride</li>
									  </ul>
									  </p>
								</button>
								</h2>
							</center>
						</div>
						<div class="modal" id="lonely_whattodonext">
							<center><h3>
								<br><br>
									<p style="font-size:large;">
										<ul class="actions">
											<li><a target="_blank" href="chat.php" class="button">Try our online chat forum</a></li>
										  </ul>
					
										  <ul class="actions">
											<li><a target="_blank" href="https://www.miniclip.com/games/genre-2/multiplayer/en/" class="button">Multiplayer games online</a></li>
										  </ul>
					
										  <ul class="actions">
											<li><a href="#help" class="button">share your story</a></li>
										  </ul>
								</p>
							</h3>
							</center>
						</div>
						<div class="modal" id="homesick_symptoms">
							<center><h2>
								<br><br>
								<button style="font-size: x-large;">
									<p style="font-size: x-large;">
									<ul>
										<li>A smile on your face</li>
										<li>Spring in you step</li>
										<li>Sparkly eyes</li>
										<li>Content and satisfied</li>
										<li>Glass half full mentality</li>
										<li>Taking each day in a stride</li>
									  </ul>
									  </p>
								</button>
								</h2>
							</center>
						</div>
						<div class="modal" id="homesick_whattodonext">
							<center><h3>
								<br><br>
									<p style="font-size:large;">
										<ul class="actions">
											<li><a target="_blank" href="https://www.insider.com/online-games-activities-to-try-with-long-distance-friends-family-2020-3" class="button">Fun activities to do with the family</a></li>
										  </ul>
					
										  <ul class="actions">
											<li><a target="_blank" href="https://www.insider.com/online-games-apps-play-with-family-kids-multiplayer" class="button">Online games to play with your parents and/or siblings</a></li>
										  </ul>
					
										  <ul class="actions">
											<li><a target="_blank" href="chat.php" class="button">Try our online chat forum</a></li>
										  </ul>
					
										  <ul class="actions">
											<li><a href="#help" class="button">share your story</a></li>
										  </ul>
					
								</p>
							</h3>
							</center>
						</div>

					</div>
				</section>


			<!-- Main -->



			<!-- Features -->
				<div class="wrapper style1">

					<section id="shareyourstory" class="container special">
						<header>
							<h2>What the <i>Community</i> said</h2>
							<!-- <p>Ipsum volutpat consectetur orci metus consequat imperdiet duis integer semper magna.</p> -->
						</header>
                        
                        <?php 
                        $link = mysqli_connect("localhost", "root", "", "stay_at_home");
        
                        // Check connection
                        if($link === false){
                            die("ERROR: Could not connect. " . mysqli_connect_error());
                        }

                        $sqselect="SELECT quote,title FROM quotes ORDER BY q_id DESC LIMIT 6";
                        $story_array=array();
                        $title_array=array();
                        if($result=mysqli_query($link, $sqselect)){
                            while ($row = mysqli_fetch_assoc($result))
                        {
                            //echo $row['quote'];
                            // print_r($row['title']);
                            array_push($story_array,$row['quote']);
                            array_push($title_array,$row['title']);
                            
                            //echo "<br><br>";
                        }
                        }
                            
                            
                        else{
                            echo "ERROR: Could not able to execute $sql. " . mysqli_error($link);
                            } 
                        
                        
                        ?>

						<div class="row">
							<article class="col-4 col-12-mobile special">
								<!-- <a  class="image featured"><img src="images/pic07.jpg" alt="" /></a> -->
								<header>
									<h3><a >
                                    <?php
                                    //Give title
                                    echo $title_array[0]
                                    
                                    ?>
                                    </a></h3>
								</header>
								<p><center>
                                    <?php
                                    
                                    echo $story_array[0]
                                    
                                    ?>
								</center></p>
							</article>
							<article class="col-4 col-12-mobile special">
								<!-- <a  class="image featured"><img src="images/pic08.jpg" alt="" /></a> -->
								<header>
									<h3><a >
                                    <?php
                                    //Give title
                                    echo $title_array[1]
                                    
                                    ?>
                                    </a>
                                </h3>
								</header>
								<p><center>
                                <?php
                                    
                                    echo $story_array[1]
                                    
                                    ?>
								</center></p>
							</article>
							<article class="col-4 col-12-mobile special">
								<!-- <a  class="image featured"><img src="images/pic09.jpg" alt="" /></a> -->
								<header>
									<h3><a >
                                    <?php
                                    //Give title
                                    echo $title_array[2]
                                    
                                    ?>
                                    </a>
                                </h3>
								</header>
								<p><center>
                                <?php
                                    
                                    echo $story_array[2]
                                    
                                    ?>
								</center></p>
                        </article>
                        <article class="col-4 col-12-mobile special">
								<!-- <a  class="image featured"><img src="images/pic09.jpg" alt="" /></a> -->
								<header>
									<h3><a >
                                    <?php
                                    //Give title
                                    echo $title_array[3]
                                    
                                    ?>
                                    </a>
                                </h3>
								</header>
								<p><center>
                                <?php
                                    
                                    echo $story_array[3]
                                    
                                    ?>
								</center></p>
                            </article>
                        
                            <article class="col-4 col-12-mobile special">
								<!-- <a  class="image featured"><img src="images/pic09.jpg" alt="" /></a> -->
								<header>
									<h3><a >
                                    <?php
                                    //Give title
                                    echo $title_array[4]
                                    
                                    ?>
                                    </a>
                                </h3>
								</header>
								<p><center>
                                <?php
                                    
                                    echo $story_array[4]
                                    
                                    ?>
								</center></p>
                            </article>
                            
                            <article class="col-4 col-12-mobile special">
								<!-- <a  class="image featured"><img src="images/pic09.jpg" alt="" /></a> -->
								<header>
									<h3><a >
                                    <?php
                                    //Give title
                                    echo $title_array[5]
                                    
                                    ?>
                                    </a>
                                </h3>
								</header>
								<p><center>
                                <?php
                                    
                                    echo $story_array[5]
                                    
                                    ?>
								</center></p>
							</article>

                        </div>
                        
						<br><br>
						<h3>Any advice/personal experience you'd like to share?</h3>
						  <p>Please enter in the box below. Including your name isn't mandatory.</p>
						<form action="insert_quote.php" method="get">
                        <input type="text" name="title" id="title" placeholder="Give a title!" ><br><br>
                            <textarea name="quote" placeholder="Remember, be nice!" id="quote" cols="70" rows="4"></textarea>
							<br>
							<input type="submit" value="Submit">  
							</form>
					</section>

				</div>


				<div class="wrapper style2">

					<article id="main" class="container special">
						<a class="image featured"><img src="images/okay_not_okay.jpg" alt="" /></a>
						<header>
							<h2><a></a>Quarantine Buddy</h2>
							<p>
								An effort to counter the stigma against psychological issues
							</p>
						</header>
						<p>
							<center>
								As per the data available on April 9, 2020, an estimated 2.6 billion people -
								One-third of the global population - were living under some kind of lockdown or
								quarantine. Some people even called the lockdown as - arguably the biggest
								psychological experiment ever conducted.
								Unfortunately, we already have an idea of the result of this experiment. In late
								February 2020, just before the mandate of lockdown in European countries, The
								Lancet published a review of 24 studies aimed at documenting the psychological
								impacts of quarantine (more specifically, “the restriction of movement of people
								who have potentially been exposed to a contagious disease”). The findings, in line
								with our expectations offer a glimpse of what is now potentially brewing among hundreds of
								millions of households around the globe.
								The findings suggest, perhaps unsurprisingly, quarantined people are very likely
								to develop a wide range of symptoms consistent in patients with psychological
								stress and disorder, including emotional exhaustion, low mood, irritability,
								anxiety, anger, stress, insomnia, depression, and post-traumatic stress symptoms.
								While more and more people are showing signs of psychological trauma, life has
								become even more difficult for people already diagnosed with some kind of
								psychological disability. People are running out of medicines and are unable to
								buy them from their local pharmacies as these medicines require a recent to be
								sold and getting the prescription becomes impossible as all the clinics remain
								closed.
								While depression and other mental health issues affect an individual’s daily
								functioning, a spike in such cases amid situations like the current coronavirus
								pandemic might go beyond personal harm - it could prove dangerous for an
								already strained public health infrastructure.
								We understand that physical distancing is not the same as social distancing and
								have hence developed Quarantine Buddy which allows the user to practice
								physical isolation while limiting (if not completely stopping) cognitive and
								emotional isolation with a hope that it will help in reducing (if not stopping), the
								ill effects of lock-downs due to disaster situations on the emotional and
							</center>
						</p>
					</article>
	
				</div>


				










			<!-- Footer -->
				<div id="footer">
					<div class="container">
						<hr />
						<div class="row">
							<div class="col-12">

								<!-- Contact -->
									<section class="contact">
										<header>
											<h3>A Collaborative Effort By</h3>
										</header>
										<p>Parth Garg | Vishesh Agrawal | Juhi Pandey | Ankit Rana | Sarthak Pal</p>
									</section>

							</div>

						</div>
					</div>
				</div>

		</div>

		<!-- Scripts -->
			<script src="assets/js/jquery.min.js"></script>
			<script src="assets/js/jquery.dropotron.min.js"></script>
			<script src="assets/js/jquery.scrolly.min.js"></script>
			<script src="assets/js/jquery.scrollex.min.js"></script>
			<script src="assets/js/browser.min.js"></script>
			<script src="assets/js/breakpoints.min.js"></script>
			<script src="assets/js/util.js"></script>
			<script src="assets/js/main.js"></script>
			<script src="popup/modal.js"></script>
	</body>
</html>