<!DOCTYPE html>
<html lang="en">
<head>
	<title>Quarantine Buddy - Login</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="css/util.css">
	<link rel="stylesheet" type="text/css" href="css/main.css">
<!--===============================================================================================-->
</head>
<body>
	
	<div class="limiter">
		<div class="container-login100">
			<div class="wrap-login100">
				<form class="login100-form validate-form" action="insert_login.php" method="get" enctype="multipart/form-data">
					<span class="login100-form-title p-b-34">
						Account Login
					</span>
					
					<div class="wrap-input100 rs1-wrap-input100 validate-input m-b-20" data-validate="Type user name">
						<input id="first-name" class="input100" type="email" name="email" placeholder="Email" required>
						<span class="focus-input100"></span>
					</div>
					<div class="wrap-input100 rs2-wrap-input100" data-validate="Type password">
						<input class="input100" type="password" name="pwd" placeholder="Password" required>
						<span class="focus-input100"></span>
					</div>

					<input type = "submit" name = "submit" value = "SUBMIT" required/>    

					<div class="w-full text-center p-t-27 p-b-239">
					</div>

					<div class="w-full text-center">
						<a href="#" class="txt3">
							Sign Up
						</a>
					</div>
				</form>

				<div class="login100-more" style="background-image: url('images/bg-01.jpg');"></div>
			</div>
		</div>
	</div>
</body>

<?php 
    if( isset($_GET['message'])) {
        echo "Wrong password, please enter again";
    }
    
	?> 
	
</html>