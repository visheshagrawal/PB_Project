<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Quarantine Buddy - Registration</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">

		<!-- LINEARICONS -->
		<link rel="stylesheet" href="fonts/linearicons/style.css">
		
		<!-- STYLE CSS -->
		<link rel="stylesheet" href="css/style_signup.css">
	</head>

	<body>

		<div class="wrapper">
			<div class="inner">
				<img src="images/image-1.png" alt="" class="image-1">
				<form action="insert_signup.php" method="get" enctype="multipart/form-data">
					<h3>New Account?</h3>
					<div class="form-holder">
						<span class="lnr lnr-user"></span>
						<input type="text" class="form-control" placeholder="Name" name="name" required>
					</div>
					<div class="form-holder">
						<span class="lnr lnr-license"></span>
						<input type="number" class="form-control" placeholder="Age" name="age" required>
					</div>
					<div class="form-holder">
						<span class="lnr lnr-envelope"></span>
						<input type="email" class="form-control" placeholder="Mail" name="email" required>
					</div>
					<div class="form-holder">
						<span class="lnr lnr-lock"></span>
						<input type="password" class="form-control" placeholder="Password" name="pwd" required>
					</div>
					<div class="form-holder">
						<span class="lnr lnr-lock"></span>
						<input type="password" class="form-control" placeholder="Confirm Password" name="cpwd" required>
					</div>
					<div class="form-holder">
						<input type = "submit" name = "submit" value = "REGISTER" required/>    
					</div>
				</form>
				<img src="images/image-2.png" alt="" class="image-2">
			</div>
			
		</div>
		
		<script src="js/main.js"></script>
	</body>
</html>